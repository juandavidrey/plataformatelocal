<div class="form-field">
	<label for="bfd-tax-shortcode"><?php _e("Category Shortcode", $this->plugin_name); ?></label>
	<input type="text" name="bfd-tax-shortcode" id="bfd-tax-shortcode" readonly />
	<p class="description">
		<?php _e("The category shortcode will appear here after you declare the category slug ", $this->plugin_name); ?>
	</p>
</div>